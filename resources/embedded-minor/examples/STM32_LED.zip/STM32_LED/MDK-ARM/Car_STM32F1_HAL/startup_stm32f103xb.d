car_stm32f1_hal\startup_stm32f103xb.o: startup_stm32f103xb.s
